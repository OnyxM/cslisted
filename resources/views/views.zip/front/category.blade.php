@extends('layouts.app')


@section('content')
    <div class="title-wrapper" style="
        background-size: 100% 100%;
        @if ($category->getFirstMediaUrl('categories'))
          background-image: url({{$category->getFirstMediaUrl('categories')}});
        @else
          background-color: light-blue;
        @endif

      ">
      <div class="container"><div class="container-inner" >
        <h1>{{ $category->name }}</h1>
      </div></div>
    </div>
    <!-- BEGIN SIDEBAR & CONTENT -->
    <div class="row margin-bottom-40 ">


      @include('front.sidebar')
      <!-- END SIDEBAR -->
      <!-- BEGIN CONTENT -->
      <div class="col-md-9 col-sm-8">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
            <li class="breadcrumb-item active">{{ $category->name }}</li>
          </ol>
        </nav>
        <h2>{{ $category->name }} postings</h2>
        <div class="row">				
          @include("front.posting-loop")
        </div>
      </div>
      <!-- END CONTENT -->
    </div>
    <!-- END SIDEBAR & CONTENT -->
@endsection

@section('before-end-content')
	@foreach ($postings as $posting)
		<div id="posting-pop-up-{{ $posting->id }}" style="display: none; width: 700px;">
		      <div class="posting-page posting-pop-up">
		        <div class="row">
		          <div class="col-md-6 col-sm-6 col-xs-3">
		            <div class="posting-main-image">
		              <img src="{{ $posting->getFirstMediaUrl() }}" alt="{{ $posting->title }}" class="img-responsive">
		            </div>
		            <div class="posting-other-images">
		            	@foreach ($posting->getMedia('postings') as $media)
			              <a href="javascript:;" class="active"><img alt="Berry Lace Dress" src="{{ $media->getFullUrl() }}"></a>
		            	@endforeach
		            </div>
		          </div>
		          <div class="col-md-6 col-sm-6 col-xs-9">
		            <h2>{{ $posting->title }}</h2>
		            <div class="price-availability-block clearfix">
		              <div class="price">
		                <strong>{{ $posting->formattedRegularPrice }} FCFA</strong>
		              </div>
		              <div class="availability">
		                Availability: <strong>In Stock ({{ $posting->quantity }})</strong>
		              </div>
		            </div>
		            <div class="description">
		              <p>{{ $posting->description }}</p>
		            </div>
		          </div>
		        </div>
		      </div>
		    <div class="posting-page-cart">
		        <div class="posting-quantity">
			        <input id="posting-quantity" type="text" value="1" readonly name="posting-quantity" class="form-control input-sm" max="{{ $posting->quantity }}">
			    </div>
		        <button class="btn btn-primary" type="submit">Add to cart</button>
		          <a href="#" class="btn btn-default">More details</a>
		    </div>
	    </div>
	@endforeach
@endsection