 <!-- BEGIN SIDEBAR -->
      <div class="sidebar col-md-3 col-sm-4">
      	<h4>Categories</h4>
        <ul class="list-group margin-bottom-25 sidebar-menu">
            @foreach ($categories as $category)
              	<li class="list-group-item clearfix
					@if ($children = $category->children())
						dropdown
					@endif
              	">
              		<a href="{{ route("category",[
                    'category_id'=>$category->id,
                    'slug'=>$category->slug,
                  ]) }}">
              			@if (count($children))
	              			<i class="fa fa-angle-right"></i>
              			@endif
              			{{ $category->name }}
              		</a>
	              	@if (count($children))
			            <ul class="dropdown-menu">
                    @if (count($children))
                      <li><a href="{{ route("category",[
                              'category_id'=>$category->id,
                              'slug'=>$category->slug,
                      ])}}"><i class="fa fa-angle-right"></i>{{ $category->name }}</a></li>
                    @endif

			            	@foreach ($children as $child)
			                  <li><a href="{{ route("category",[
                          'category_id'=>$child->id,
                          'slug'=>$child->slug,
                  ])}}"><i class="fa fa-angle-right"></i>{{ $child->name }}</a></li>
			            	@endforeach
		                </ul>
	              	@endif
              	</li>
            @endforeach
        </ul>
        <h4>Cities</h4>
        <ul class="list-group margin-bottom-25 sidebar-menu">
            @foreach ($cities as $city)
              	<li class="list-group-item clearfix">
              		<a href="{{ route('city',[
                    'id'=>$city->id,
                    'name'=>$city->name,
                  ]) }}">
              			{{ $city->name }}
              		</a>
              	</li>
            @endforeach
        </ul>
        <h2>Tags</h2>
        <div class="sidebar-filter margin-bottom-25">
          <div class="checkbox-list">
            @foreach ($tags as $tag)
                <label><input type="checkbox[]">{{ $tag->name }}</label>
            @endforeach
          </div>
        </div>
      </div>