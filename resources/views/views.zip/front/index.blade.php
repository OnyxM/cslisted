@extends('layouts.app')


@section('content')
    <!-- BEGIN SIDEBAR & CONTENT -->
   @include('front.sidebar')

    <!-- END SIDEBAR & CONTENT -->
     <div class="col-md-9 col-sm-8">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
          </ol>
        </nav>
        <h2>Postings</h2>
        <div class="row">       
          @include("front.posting-loop")
        </div>
      </div>
    <!-- END TWO PRODUCTS & PROMO -->
@endsection
