@extends('layouts.app')


@section('content')
<!-- BEGIN SIDEBAR & CONTENT -->
@include('front.sidebar')

<!-- END SIDEBAR & CONTENT -->
<div class="col-md-9 col-sm-8">
	<nav aria-label="breadcrumb">
		<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item active">{{ $posting->name }}</li>
		</ol>
	</nav>
	<h2>{{ $posting->name }}</h2>
	@php
		$reviews = $posting->activeSortedReviews();
	@endphp

	<div class="row"> 
		<div class="product-page">
			<div class="row">
				<div class="col-md-6 col-sm-6">
					<div class="product-main-image">
						<img src="{{ $posting->getFirstMediaurl('postings') }}" alt="Cool green dress with red bell" class="img-responsive" data-BigImgsrc="assets/pages/img/products/model7.jpg">
					</div>
					<div class="product-other-images">
						@foreach ($posting->getMedia('postings') as $media)
							<a href="{{ $media->getFullUrl() }}" class="fancybox-button" rel="photos-lib"><img alt="$posting->name" src="{{ $media->getFullUrl() }}"></a>
						@endforeach
					</div>
				</div>
				<div class="col-md-6 col-sm-6">
					<h1>{{ $posting->name }}</h1>
					<div class="price-availability-block clearfix">
						<div class="price">
							<strong>{{ $posting->formattedRegularPrice }}<span> FCFA</span></strong>
							@if ($posting->discount_price)
								<em> <span>{{ $posting->FormattedDiscountPrice }}</span> FCFA</em>
							@endif
						</div>
						<div class="availability">
							Availability: <strong>In Stock</strong>
						</div>
					</div>
					<div class="description">
						<p>{!!html_entity_decode($posting->description)!!}</p>
					</div>
					<div class="product-page-cart">
						<div class="product-quantity">
							<input id="product-quantity" type="text" value="1" readonly class="form-control input-sm">
						</div>
						<button class="btn btn-primary" type="submit">Add to cart</button>
					</div>
					<div class="review">
						<input type="range" value="4" step="0.25" id="backing4">
						<div class="rateit" data-rateit-backingfld="#backing4" data-rateit-resetable="false"  data-rateit-ispreset="true" data-rateit-min="0" data-rateit-max="5">
						</div>
						<a href="javascript:;">{{ $reviews->count() }} reviews</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="#form-review">Write a review</a>
					</div>
				</div>

				<div class="product-page-content">
					<ul id="myTab" class="nav nav-tabs">
						<li class="active"><a href="#Reviews" data-toggle="tab">Reviews ({{ $reviews->count() }} )</a></li>
					</ul>
					<div id="myTabContent" class="tab-content">
						<div class="tab-pane fade in active" id="Reviews">
							@if ($reviews->count() <= 0)
								<p>There are no reviews for this product.</p>
							@else
								@foreach ($reviews as $review)
									<div class="review-item clearfix">
										<div class="review-item-submitted">
											<strong>{{ $review->owner_name }}</strong>
											<em>{{ $posting->created_at }}</em>
											<div class="rateit" data-rateit-value="5" data-rateit-ispreset="true" data-rateit-readonly="true"></div>
										</div>                                              
										<div class="review-item-content">
											<p>{{ $review->content }}</p>
										</div>
									</div>
								@endforeach
							@endif
							<!-- BEGIN FORM-->
							<form action="{{ route('review.store') }}" method="POST" class="reviews-form" id='form-review' role="form">
								@csrf
								<h2>Write a review</h2>
								@if(isset($errors))
									@if ($errors->any())
								        <div class="alert alert-danger">
								          <ul>
								            @foreach ($errors->all() as $error)
								            <li>{{ $error }}</li>
								            @endforeach
								          </ul>
								        </div>
								    @endif
							    @endif
							    @if (Session::has('success'))
							    	<div class="alert alert-success">{{Session::get('success')}}</div> 
							    @endif
								<div class="form-group">
									<label for="name">Name <span class="require">*</span></label>
									<input type="text" name="owner_name" class="form-control" id="name">
								</div>
								<div class="form-group">
									<label for="email">Email</label>
									<input type="text" name="owner_email" class="form-control" id="email">
								</div>
								<div class="form-group">
									<label for="review">Review <span class="require">*</span></label>
									<textarea class="form-control" name="content" rows="8" id="review"></textarea>
								</div>
								<div class="form-group">
									<label for="email">Rating</label>
									<input type="range" value="4" step="0.25" id="backing5" name="rating">
									<div class="rateit" data-rateit-backingfld="#backing5" data-rateit-resetable="false"  data-rateit-ispreset="true" data-rateit-min="0" data-rateit-max="5">
									</div>
								</div>
								<input type="hidden" name="posting_id" value="{{ $posting->id }}">
								<div class="padding-top-20">                  
									<button type="submit" class="btn btn-primary">Send</button>
								</div>
							</form>
							<!-- END FORM--> 
						</div>
					</div>
				</div>
			</div>
		</div>     
	</div>
</div>
<!-- END TWO PRODUCTS & PROMO -->
@endsection