@foreach ($postings as $posting)
  <div class="col-sm-6 col-lg-4 margin-bottom-25">
        <div class="product-item">
          <div class="pi-img-wrapper">
            <img src="{{ $posting->getFirstMediaUrl('postings') }}" class="img-responsive" alt="{{
            	$posting->title 
            }}">
            <div>
              <a href="{{ $posting->getFirstMediaUrl('postings') }}" class="btn btn-default fancybox-button">Zoom</a>
            </div>
          </div>
            
          <h3><a href="{{ route('single-posting',[
            'slug'=>$posting->slug,
            'id'=>$posting->id
          ]) }}">{{ $posting->name }}</a></h3>
          <div class="pi-price" >{{ $posting->formattedRegularPrice }} FCFA</div>
          <a href="{{ route('add-cart',[
            'id' => $posting->id
          ]) }}" class="btn btn-default add2cart">Add to cart</a>
          {{-- <div class="sticker sticker-new"></div> --}}
        </div>
  </div>
@endforeach

@if (!count($postings))
<div class="mt-4 p-3 text-center">
	<h3>No postings found!</h3>
</div>
@endif