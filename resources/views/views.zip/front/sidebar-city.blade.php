 <!-- BEGIN SIDEBAR -->
  <div class="sidebar col-md-3 col-sm-4">
  	<h4>Categories</h4>
    <ul class="list-group margin-bottom-25 sidebar-menu">
        @foreach ($categories as $cat)
          	<li class="list-group-item clearfix
    					@if ($children = $cat->children())
    						dropdown
    					@endif
          	"
            >
          		<a href="{{ route("category_city",[
                'category_id'=>$cat->id,
                'category_slug'=>$cat->slug,
                'city_slug'=>$city->slug,
                'city_id'=>$city->id,
              ]) }}">
          			@if (count($children))
            			<i class="fa fa-angle-right"></i>
          			@endif
          			{{ $cat->name }}
          		</a>
            	@if (count($children))
	            <ul class="dropdown-menu"  
                @if ((isset($category)) && $children->pluck('id')->contains($category->id))
                  style="display: block;"
                @endif
              >
                @if (count($children))
                  <li><a href="{{ route("category_city",[
                          'category_id'=>$cat->id,
                          'category_slug'=>$cat->slug,
                          'city_slug'=>$city->slug,
                          'city_id'=>$city->id,

                  ])}}"

                  @if (isset($category) && $cat->id === $category->id)
                   class="active" 
                  @endif

                  ><i class="fa fa-angle-right"></i>{{ $cat->name }}</a></li>
                @endif

	            	@foreach ($children as $child)
	                  <li><a href="{{ route("category_city",[
                      'category_id'=>$child->id,
                      'category_slug'=>$child->slug,
                      'city_slug'=>$city->slug,
                      'city_id'=>$city->id,

                  ])}}

                  "
                  @if (isset($category) && $cat->id === $category->id)
                   class='active' 
                  @endif
                  ><i class="fa fa-angle-right"></i>{{ $child->name }}</a></li>
	            	@endforeach
                </ul>
            	@endif
          	</li>
        @endforeach
    </ul>
    <h4>Cities</h4>
    <ul class="list-group margin-bottom-25 sidebar-menu">
        @foreach ($cities as $cit)
          	<li class="list-group-item
              @if ($cit->id === $city->id)
                active
              @endif
            clearfix">
          		<a href="{{ route('city',[
                'id'=>$cit->id,
                'name'=>$cit->name,
              ]) }}">
          			{{ $cit->name }}
          		</a>
          	</li>
        @endforeach
    </ul>
    <h2>Tags</h2>
    <div class="sidebar-filter margin-bottom-25">
      <div class="checkbox-list">
        <form action="#" method="GET">
          @foreach ($tags as $tag)
              <label><input type="checkbox[]">{{ $tag->name }}</label>
          @endforeach

          <button class="btn btn-info" type="submit">Submit</button>
        </form>
      </div>
    </div>
  </div>