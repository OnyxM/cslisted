@extends('layouts.app')


@section('content')
     <!-- BEGIN CONTENT -->
          <div class="col-md-12 col-sm-12">
            <h1>Shopping cart</h1>
            <div class="goods-page">
              <div class="goods-data clearfix">
                <div class="table-wrapper-responsive">
                <table summary="Shopping cart">
                  <tr>
                    <th class="goods-page-image">Image</th>
                    <th class="goods-page-description">Description</th>
                    <th class="goods-page-quantity">Quantity</th>
                    <th class="goods-page-price">Unit price</th>
                    <th class="goods-page-total" colspan="2">Total</th>
                  </tr>
                  @foreach ($cartContent as $content)
                    <tr>
                      <td class="goods-page-image">
                        <a href="javascript:;"><img src="{{ $content->attributes['image_url'] }}" alt="Berry Lace Dress"></a>
                      </td>
                      <td class="goods-page-description">
                        <h3><a href="javascript:;">{{$content->name}}</a></h3>
                        <p>{{$content->description}}</p>
                      </td>
                      <td class="goods-page-quantity">
                        {{ $content->quantity }}
                      </td>
                      <td class="goods-page-price">
                        <strong>{{ $content->price }} FCFA</strong>
                      </td>
                      <td class="goods-page-total">
                        <strong>{{ $content->price * $content->quantity }} FCFA</strong>
                      </td>
                      <td class="del-goods-col">
                        <a class="del-goods" href="{{ route('remove-cart',[
                          'id' => $content->id
                        ]) }}">&nbsp;</a>
                      </td>
                    </tr>
                  @endforeach
                </table>
                </div>
                @if ($cartContent->count())
                  <div class="shopping-total">
                    <ul>
                      <li class="shopping-total-price">
                        <em>Total</em>
                        <strong class="price">{{ Cart::getTotal() }} <span>FCFA</span></strong>
                      </li>
                    </ul>
                  </div>
                @else
                  <h3>Your cart is emty</h3>
                @endif
              </div>
              <a href="{{ route('home') }}" class="btn btn-default">Continue shopping <i class="fa fa-shopping-cart"></i></a>
              <button class="btn btn-primary" type="submit">Checkout <i class="fa fa-check"></i></button>
            </div>
          </div>
          <!-- END CONTENT -->
@endsection
