  <!-- BEGIN SIDEBAR -->
  <div class="sidebar col-md-3 col-sm-3">
    <ul class="list-group margin-bottom-25 sidebar-menu">
      <li class="list-group-item clearfix"><a href="{{ route('posting.index') }}"><i class="fa fa-angle-right"></i>Products</a></li>
      <li class="list-group-item clearfix"><a href="{{ route('category.index') }}"><i class="fa fa-angle-right"></i> Categories</a></li>
      <li class="list-group-item clearfix"><a href="{{ route('city.index') }}"><i class="fa fa-angle-right"></i> Cities</a></li>
      <li class="list-group-item clearfix"><a href="{{ route('tag.index') }}"><i class="fa fa-angle-right"></i> Tags</a></li>
      <li class="list-group-item clearfix"><a href="{{ route('post_type.index') }}"><i class="fa fa-angle-right"></i> Post Type</a></li>
      <li class="list-group-item clearfix"><a href="{{ route('review.index') }}"><i class="fa fa-angle-right"></i>Reviews</a></li>
    </ul>
  </div>
  <!-- END SIDEBAR -->